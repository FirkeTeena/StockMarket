# simple-web-maven-app


    https://jenkins.io/doc/tutorials/build-a-java-app-with-maven/