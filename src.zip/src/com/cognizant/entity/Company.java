package com.cognizant.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="company")
public class Company implements Serializable
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int CompanyId;
	private String CompanyName;
	private long Turnover;
	private String CEO;
	private String BoardOfDirectors;
	private boolean ListedInStockExchanges;
	private String Sector;
	private String BriefWriteup;
	private String StockCode;
	public int getCompanyId() {
		return CompanyId;
	}
	public void setCompanyId(int companyId) {
		CompanyId = companyId;
	}
	public String getCompanyName() {
		return CompanyName;
	}
	public void setCompanyName(String companyName) {
		CompanyName = companyName;
	}
	public long getTurnover() {
		return Turnover;
	}
	public void setTurnover(long turnover) {
		Turnover = turnover;
	}
	public String getCEO() {
		return CEO;
	}
	public void setCEO(String cEO) {
		CEO = cEO;
	}
	public String getBoardOfDirectors() {
		return BoardOfDirectors;
	}
	public void setBoardOfDirectors(String boardOfDirectors) {
		BoardOfDirectors = boardOfDirectors;
	}
	public boolean isListedInStockExchanges() {
		return ListedInStockExchanges;
	}
	public void setListedInStockExchanges(boolean listedInStockExchanges) {
		ListedInStockExchanges = listedInStockExchanges;
	}
	public String getSector() {
		return Sector;
	}
	public void setSector(String sector) {
		Sector = sector;
	}
	public String getBriefWriteup() {
		return BriefWriteup;
	}
	public void setBriefWriteup(String briefWriteup) {
		BriefWriteup = briefWriteup;
	}
	public String getStockCode() {
		return StockCode;
	}
	public void setStockCode(String stockCode) {
		StockCode = stockCode;
	}
	@Override
	public String toString() {
		return "Company [CompanyId=" + CompanyId + ", CompanyName=" + CompanyName + ", Turnover=" + Turnover + ", CEO="
				+ CEO + ", BoardOfDirectors=" + BoardOfDirectors + ", ListedInStockExchanges=" + ListedInStockExchanges
				+ ", Sector=" + Sector + ", BriefWriteup=" + BriefWriteup + ", StockCode=" + StockCode + "]";
	}
	
	

}
